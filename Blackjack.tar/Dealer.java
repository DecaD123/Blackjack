//Name -
//Date -

public class Dealer extends Player
{
	//define a deck of cards

	public Dealer() {
	}

	public void  shuffle()
	{
	   //shuffle the deck
	}

	public Card  deal(){
	   return null;
	}
	
	public int numCardsLeftInDeck()
	{
		return 0;
	}

	public boolean hit()
	{
	   return false;
    }
}








