//Name -
//Date -

import static java.lang.System.*;
import java.util.Scanner;

public class BlackJack
{
	//add in Player instance variable
	//add in Dealer instance variable

	public BlackJack()
	{
	}

	public void playGame()
	{
		Scanner keyboard = new Scanner(System.in);
		char choice = 0;
	}
	
	public static void main(String[] args)
	{
		BlackJack game = new BlackJack();
		game.playGame();
	}
}