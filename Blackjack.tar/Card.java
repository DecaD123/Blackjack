//Name -
//Date -

public class Card
{
	public static final String FACES[] = {"ZERO","ACE","TWO","THREE","FOUR",
			"FIVE","SIX","SEVEN","EIGHT","NINE","TEN","JACK","QUEEN","KING"};

	private String suit;
	private int face;

  	//constructors


	// modifiers


  	//accessors

  	public int getValue()
  	{
  		return face;
  	}

	public boolean equals(Object obj)
	{
		return false;
	}

  	//toString
  	
 }